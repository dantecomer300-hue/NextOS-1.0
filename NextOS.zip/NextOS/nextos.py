import tkinter as tk
from tkinter import messagebox, simpledialog
import json
import os

# File storage
ACCOUNTS_FILE = "accounts.json"
FILES_DIR = "user_files"

# Ensure folders exist
if not os.path.exists(FILES_DIR):
    os.makedirs(FILES_DIR)

# Load accounts
if os.path.exists(ACCOUNTS_FILE):
    with open(ACCOUNTS_FILE, "r") as f:
        accounts = json.load(f)
else:
    accounts = {}

# Save accounts
def save_accounts():
    with open(ACCOUNTS_FILE, "w") as f:
        json.dump(accounts, f)

class MiniOS:
    def __init__(self, root):
        self.root = root
        self.root.title("NextOS")
        self.root.attributes("-fullscreen", True)
        self.current_user = None
        self.login_screen()

    def clear_screen(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    # LOGIN
    def login_screen(self):
        self.clear_screen()
        frame = tk.Frame(self.root, bg="black")
        frame.pack(fill="both", expand=True)

        tk.Label(frame, text="NextOS Login", fg="white", bg="black", font=("Arial", 30)).pack(pady=40)

        self.username_entry = tk.Entry(frame, font=("Arial", 16))
        self.username_entry.pack(pady=10)
        self.username_entry.insert(0, "Username")

        self.password_entry = tk.Entry(frame, show="*", font=("Arial", 16))
        self.password_entry.pack(pady=10)
        self.password_entry.insert(0, "Password")

        tk.Button(frame, text="Login", command=self.login).pack(pady=10)
        tk.Button(frame, text="Create Account", command=self.create_account_screen).pack(pady=10)
        tk.Button(frame, text="Exit", command=self.root.destroy).pack(pady=10)

    def login(self):
        user = self.username_entry.get()
        pw = self.password_entry.get()
        if user in accounts and accounts[user] == pw:
            self.current_user = user
            self.desktop()
        else:
            messagebox.showerror("Error", "Invalid login")

    # CREATE ACCOUNT
    def create_account_screen(self):
        self.clear_screen()
        frame = tk.Frame(self.root, bg="black")
        frame.pack(fill="both", expand=True)

        tk.Label(frame, text="Create Account", fg="white", bg="black", font=("Arial", 30)).pack(pady=40)

        self.new_user = tk.Entry(frame, font=("Arial", 16))
        self.new_user.pack(pady=10)
        self.new_pass = tk.Entry(frame, show="*", font=("Arial", 16))
        self.new_pass.pack(pady=10)

        tk.Button(frame, text="Create", command=self.create_account).pack(pady=10)
        tk.Button(frame, text="Back", command=self.login_screen).pack(pady=10)

    def create_account(self):
        user = self.new_user.get()
        pw = self.new_pass.get()
        if user in accounts:
            messagebox.showerror("Error", "User exists")
        else:
            accounts[user] = pw
            save_accounts()
            messagebox.showinfo("Success", "Account created")
            self.login_screen()

    # DESKTOP
    def desktop(self):
        self.clear_screen()
        frame = tk.Frame(self.root, bg="#1e1e1e")
        frame.pack(fill="both", expand=True)

        tk.Label(frame, text=f"Welcome {self.current_user}", fg="white", bg="#1e1e1e", font=("Arial", 20)).pack(pady=20)

        tk.Button(frame, text="File Manager", command=self.file_manager).pack(pady=10)
        tk.Button(frame, text="Logout", command=self.login_screen).pack(pady=10)

    # FILE MANAGER
    def file_manager(self):
        win = tk.Toplevel(self.root)
        win.title("File Manager")
        win.geometry("500x400")

        user_dir = os.path.join(FILES_DIR, self.current_user)
        if not os.path.exists(user_dir):
            os.makedirs(user_dir)

        listbox = tk.Listbox(win)
        listbox.pack(fill="both", expand=True)

        def refresh():
            listbox.delete(0, tk.END)
            for f in os.listdir(user_dir):
                listbox.insert(tk.END, f)

        def create_file():
            name = simpledialog.askstring("File Name", "Enter file name:")
            if name:
                with open(os.path.join(user_dir, name + ".txt"), "w") as f:
                    f.write("")
                refresh()

        def open_file():
            selection = listbox.get(tk.ACTIVE)
            if not selection:
                return

            file_path = os.path.join(user_dir, selection)

            editor = tk.Toplevel(win)
            editor.title(selection)
            editor.geometry("400x300")

            text = tk.Text(editor)
            text.pack(fill="both", expand=True)

            with open(file_path, "r") as f:
                text.insert("1.0", f.read())

            def save_file():
                with open(file_path, "w") as f:
                    f.write(text.get("1.0", tk.END))
                messagebox.showinfo("Saved", "File saved")

            tk.Button(editor, text="Save", command=save_file).pack()

        def delete_file():
            selection = listbox.get(tk.ACTIVE)
            if selection:
                os.remove(os.path.join(user_dir, selection))
                refresh()

        tk.Button(win, text="New File", command=create_file).pack()
        tk.Button(win, text="Open", command=open_file).pack()
        tk.Button(win, text="Delete", command=delete_file).pack()

        refresh()

# RUN
if __name__ == "__main__":
    root = tk.Tk()
    app = MiniOS(root)
    root.mainloop()
